import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.39 loads the screenshot-led correction layer in the real app shell', () => {
  const html = read('index.html');
  assert.match(html, /rebuild-v98\.39\.css/);
  assert.match(html, /1\.98\.46-v98\.46/);
});

test('v98.39 removes touch-pinned skip-link outline and display boundary', () => {
  const css = read('assets/css/rebuild-v98.39.css');
  assert.match(css, /\.skip-to-workspace:focus:not\(:focus-visible\)/);
  assert.match(css, /clip-path:\s*inset\(50%\)/);
  assert.match(css, /\.skip-to-workspace:focus-visible[\s\S]*clip-path:\s*none/);
  assert.match(css, /#screen-calc \.calc-display[\s\S]*border:\s*0\s*!important/);
  assert.match(css, /#screen-calc \.calc-expression-row,[\s\S]*border:\s*0\s*!important/);
});

test('v98.39 gives keypad and bottom navigation a bounded flex layout', () => {
  const css = read('assets/css/rebuild-v98.39.css');
  assert.match(css, /\.bottom-navigation[\s\S]*flex:\s*0 0 64px/);
  assert.match(css, /#screen-calc \.main-keypad[\s\S]*min-height:\s*0\s*!important/);
});

test('scientific calculator is searchable and launchable from the tool menu', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  assert.match(html, /id="btn-sci-open"/);
  assert.match(html, /id="btn-sci-inline"/);
  assert.match(js, /const btnSci = document.getElementById\('btn-sci-open'\)/);
  assert.match(js, /btn-sci-open/);
});

test('converter keypad utility controls retain accessible actions and clean glyphs', () => {
  const html = read('index.html');
  const css = read('assets/css/rebuild-v98.39.css');
  assert.match(html, /data-num="NEXT" title="Switch input field" aria-label="Switch input field"/);
  assert.match(html, /data-num="DONE" title="Close keypad" aria-label="Close keypad"/);
  assert.match(css, /data-num="NEXT"\]\s*\{ font-size: 0 !important/);
  assert.match(css, /content:\s*"⇄"/);
});

test('Android build and offline cache require v98.39 stylesheet', () => {
  assert.match(read('scripts/prepare-android-web.mjs'), /assets\/css\/rebuild-v98\.39\.css/);
  assert.match(read('service-worker.js'), /assets\/css\/rebuild-v98\.39\.css/);
});
