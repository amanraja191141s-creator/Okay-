# QA results — SA Calculator v98.40

- Automated Node test suite: **286 passed, 0 failed**
- `npm run build:web`: **PASS** (18 required assets verified; service worker included)
- `node --check assets/js/app.js`: **PASS**
- `node --check service-worker.js`: **PASS**
- `node --check scripts/prepare-android-web.mjs`: **PASS**
- YAML parse: **PASS** for active workflow and both release copies
- Workflow synchronization: **PASS** (active workflow, `android-apk.yml`, and `SA-Calculator-v98.40-Android-Workflow.yml` byte-identical)
- Package/manifest/runtime version: **1.98.40-v98.40**
- Android versionCode computed by native patch script: **1098040**
- Android offline bundle contains and precaches `rebuild-v98.40.css`: **PASS**
- Physical Android installation and visual/performance profiling: **NOT YET RUN**
