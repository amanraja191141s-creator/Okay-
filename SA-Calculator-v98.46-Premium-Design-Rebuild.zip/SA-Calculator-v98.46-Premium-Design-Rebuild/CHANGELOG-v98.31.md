# v98.32 change register

1. Visible hamburger menu on home.
2. Single tool toolbar retained for tool pages.
3. Searchable all-tools drawer.
4. Category groups: converters, everyday, finance/shopping, date/time, vehicle, study/wellness.
5. Dynamic quick access from saved favorites.
6. Favorites do not remove tools from All Tools.
7. Help, Scientific and History quick actions.
8. Search clear action and empty state.
9. 105 currency codes receive representative flags.
10. Currency picker shows flag, name, ISO code and selected state.
11. Currency picker retains alphabetical index.
12. Currency picker remains searchable by name/code.
13. Scientific functions grouped by family.
14. Constants group.
15. Powers and roots group.
16. Logarithms group.
17. Trigonometry group.
18. Hyperbolic group.
19. DEG/RAD information in scientific heading.
20. Memory controls preserved.
21. Parentheses and double-zero actions preserved.
22. On-demand keyboard safe-area aware.
23. Focused field preview improved.
24. Delete, next, clear and done controls retained.
25. Tool cards and result panels unified.
26. Input sizing and spacing standardized.
27. Primary actions unified.
28. Responsive small-phone rules added.
29. Scientific modal adapts to compact height.
30. Bottom navigation active state refined.
31. Version/cache identity updated.
32. Android workflow versionCode updated.

No calculation engine was intentionally deleted or rewritten as part of this UI-only rebuild.
