# SA Calculator v98.46

SA Calculator is a mobile-first calculator and utility app. This release consolidates the visual language into a unified premium design layer while preserving existing calculation and navigation systems.

## Build
- `npm test` — full regression suite
- `npm run build:web` — regenerate the single production CSS bundle and Android `www` assets
- `npm run android:apk` — build a debug APK when Android SDK/Gradle dependencies are available

## Release identity
- Package: `1.98.46-v98.46`
- Android versionCode: `1098046`
- Service-worker cache: `sa-calculator-v98-46-unified-premium-design`

## Design system
`assets/css/rebuild-v98.46.css` is the final design layer. `scripts/prepare-android-web.mjs` concatenates it after the preserved earlier layers into `assets/css/app.css`, then copies the exact bundle to `www`.
